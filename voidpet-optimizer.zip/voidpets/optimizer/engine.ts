// ============================================================
// VOIDPETS META BUILD OPTIMIZER — Stat Scaling Engine
// Implements the canonical stat formula:
//   FinalStat = (BaseStat + Level×Growth + Equipment + Passive)
//               × RarityMultiplier × EvolutionMultiplier
// ============================================================

import {
  Pet, Equipment, BuildEquipment, Passive, BaseStats,
  StatBreakdown, StatCalculationInput, StatCalculationResult,
  EvolutionStage, PassiveEffect, ModifierType, Build,
  BuildRole, GameMode, BuildRequest, OptimizationResult,
  GeneticAlgorithmConfig, MonteCarloConfig, OptimizationStrategy,
} from '../shared/types';

// ─── Constants ───────────────────────────────────────────────

const EVOLUTION_MULTIPLIERS: Record<EvolutionStage, number> = {
  [EvolutionStage.BASE]: 1.0,
  [EvolutionStage.EVOLVED_1]: 1.15,
  [EvolutionStage.EVOLVED_2]: 1.30,
  [EvolutionStage.ASCENDED]: 1.50,
};

/**
 * Role weight tables define how much each stat matters for scoring.
 * Values are weights summing to ~1.0 per role.
 */
const ROLE_WEIGHTS: Record<BuildRole, Partial<Record<keyof BaseStats, number>>> = {
  [BuildRole.DPS]: {
    atk: 0.35, critRate: 0.20, critDmg: 0.20, spd: 0.10,
    voidPwr: 0.08, hp: 0.04, accuracy: 0.03,
  },
  [BuildRole.TANK]: {
    def: 0.35, hp: 0.30, voidRes: 0.15, spd: 0.08,
    atk: 0.07, energy: 0.05,
  },
  [BuildRole.SUPPORT]: {
    energy: 0.25, def: 0.20, hp: 0.20, spd: 0.15,
    atk: 0.10, voidPwr: 0.10,
  },
  [BuildRole.HYBRID]: {
    atk: 0.22, def: 0.18, hp: 0.18, spd: 0.12,
    critRate: 0.10, critDmg: 0.10, energy: 0.10,
  },
  [BuildRole.VOID_BURST]: {
    voidPwr: 0.30, atk: 0.25, critDmg: 0.20, critRate: 0.12,
    spd: 0.08, voidRes: 0.05,
  },
};

/**
 * Stat normalization baselines — used to convert raw stats into
 * a 0-100 effectiveness score for cross-stat comparison.
 */
const STAT_BASELINES: Record<keyof BaseStats, number> = {
  atk: 500, def: 500, hp: 5000, spd: 300,
  critRate: 80, critDmg: 250, voidRes: 100,
  voidPwr: 100, energy: 200, accuracy: 100,
};

// ─── Stat Scaling Engine ─────────────────────────────────────

export class StatEngine {
  /**
   * Main stat calculation formula.
   * FinalStat = (Base + Level×Growth + Equipment + Passive) × Rarity × Evolution
   */
  static calculate(input: StatCalculationInput): StatCalculationResult {
    const { pet, level, equipment, activePassives = [] } = input;

    // 1. Base stats
    const baseStats: BaseStats = {
      atk: pet.baseAtk, def: pet.baseDef, hp: pet.baseHp, spd: pet.baseSpd,
      critRate: pet.baseCritRate, critDmg: pet.baseCritDmg,
      voidRes: pet.baseVoidRes, voidPwr: pet.baseVoidPwr,
      energy: pet.baseEnergy, accuracy: pet.baseAccuracy,
    };

    // 2. Level growth bonus (linear scaling)
    const levelBonus: BaseStats = {
      atk: level * pet.growthAtk, def: level * pet.growthDef,
      hp: level * pet.growthHp, spd: level * pet.growthSpd,
      critRate: level * pet.growthCritRate, critDmg: level * pet.growthCritDmg,
      voidRes: level * pet.growthVoidRes, voidPwr: level * pet.growthVoidPwr,
      energy: level * pet.growthEnergy, accuracy: level * pet.growthAccuracy,
    };

    // 3. Equipment bonus (additive per slot)
    const equipmentBonus = this.calculateEquipmentBonus(equipment);

    // 4. Passive effects (additive first, then multiplicative)
    const passiveBonus = this.calculatePassiveBonus(activePassives);

    // 5. Set bonuses
    const setBonuses = this.calculateSetBonuses(equipment);

    // 6. Sum additive components
    const additiveSum: BaseStats = {
      atk: baseStats.atk + levelBonus.atk + equipmentBonus.atk + passiveBonus.atk + setBonuses.atk,
      def: baseStats.def + levelBonus.def + equipmentBonus.def + passiveBonus.def + setBonuses.def,
      hp: baseStats.hp + levelBonus.hp + equipmentBonus.hp + passiveBonus.hp + setBonuses.hp,
      spd: baseStats.spd + levelBonus.spd + equipmentBonus.spd + passiveBonus.spd + setBonuses.spd,
      critRate: Math.min(100, baseStats.critRate + levelBonus.critRate + equipmentBonus.critRate + passiveBonus.critRate + setBonuses.critRate),
      critDmg: baseStats.critDmg + levelBonus.critDmg + equipmentBonus.critDmg + passiveBonus.critDmg + setBonuses.critDmg,
      voidRes: Math.min(100, baseStats.voidRes + levelBonus.voidRes + equipmentBonus.voidRes + passiveBonus.voidRes + setBonuses.voidRes),
      voidPwr: baseStats.voidPwr + levelBonus.voidPwr + equipmentBonus.voidPwr + passiveBonus.voidPwr + setBonuses.voidPwr,
      energy: baseStats.energy + levelBonus.energy + equipmentBonus.energy + passiveBonus.energy + setBonuses.energy,
      accuracy: Math.min(100, baseStats.accuracy + levelBonus.accuracy + equipmentBonus.accuracy + passiveBonus.accuracy + setBonuses.accuracy),
    };

    // 7. Apply rarity and evolution multipliers (multiplicative)
    const rarityMult = pet.rarityMultiplier;
    const evoMult = EVOLUTION_MULTIPLIERS[pet.evolutionStage];
    const totalMult = rarityMult * evoMult;

    const finalStats: BaseStats = {
      atk: Math.round(additiveSum.atk * totalMult),
      def: Math.round(additiveSum.def * totalMult),
      hp: Math.round(additiveSum.hp * totalMult),
      spd: Math.round(additiveSum.spd), // SPD not scaled by rarity — intentional
      critRate: Math.min(100, Math.round(additiveSum.critRate * 10) / 10),
      critDmg: Math.round(additiveSum.critDmg * totalMult),
      voidRes: Math.min(100, Math.round(additiveSum.voidRes)),
      voidPwr: Math.round(additiveSum.voidPwr * totalMult),
      energy: Math.round(additiveSum.energy),
      accuracy: Math.min(100, Math.round(additiveSum.accuracy)),
    };

    return {
      finalStats,
      breakdown: {
        base: baseStats,
        levelBonus,
        equipmentBonus,
        passiveBonus,
        setBonuses,
        rarityMultiplier: rarityMult,
        evolutionMultiplier: evoMult,
      },
    };
  }

  private static calculateEquipmentBonus(equipment: BuildEquipment): BaseStats {
    const bonus: BaseStats = this.zeroStats();
    const slots: Array<Equipment | undefined> = [
      equipment.weapon, equipment.armor, equipment.accessory,
      equipment.relic, equipment.core,
    ];
    for (const eq of slots) {
      if (!eq) continue;
      bonus.atk += eq.statBonuses?.atk ?? 0;
      bonus.def += eq.statBonuses?.def ?? 0;
      bonus.hp += eq.statBonuses?.hp ?? 0;
      bonus.spd += eq.statBonuses?.spd ?? 0;
      bonus.critRate += eq.statBonuses?.critRate ?? 0;
      bonus.critDmg += eq.statBonuses?.critDmg ?? 0;
      bonus.voidRes += eq.statBonuses?.voidRes ?? 0;
      bonus.voidPwr += eq.statBonuses?.voidPwr ?? 0;
      bonus.energy += eq.statBonuses?.energy ?? 0;
      bonus.accuracy += eq.statBonuses?.accuracy ?? 0;
    }
    return bonus;
  }

  private static calculatePassiveBonus(passives: Passive[]): BaseStats {
    const additive: BaseStats = this.zeroStats();
    // Additive pass
    for (const passive of passives) {
      for (const effect of passive.effects) {
        if (effect.modifier === ModifierType.ADDITIVE) {
          const key = this.statTypeToKey(effect.stat);
          if (key) (additive as Record<string, number>)[key] += effect.value;
        }
      }
    }
    return additive;
  }

  private static calculateSetBonuses(equipment: BuildEquipment): BaseStats {
    const bonus = this.zeroStats();
    const setMap = new Map<string, number>();

    for (const eq of [equipment.weapon, equipment.armor, equipment.accessory, equipment.relic, equipment.core]) {
      if (eq?.setName) {
        setMap.set(eq.setName, (setMap.get(eq.setName) ?? 0) + 1);
      }
    }

    for (const [setName, count] of setMap) {
      for (const eq of [equipment.weapon, equipment.armor, equipment.accessory, equipment.relic, equipment.core]) {
        if (eq?.setName === setName && eq?.setBonus && count >= eq.setBonus.requiredPieces) {
          const sb = eq.setBonus.bonuses;
          bonus.atk += sb.atk ?? 0;
          bonus.def += sb.def ?? 0;
          bonus.hp += sb.hp ?? 0;
          bonus.critRate += sb.critRate ?? 0;
          bonus.critDmg += sb.critDmg ?? 0;
          break; // apply set bonus once
        }
      }
    }

    return bonus;
  }

  /** Convert raw stats to a 0-100 role effectiveness score */
  static scoreForRole(stats: BaseStats, role: BuildRole): number {
    const weights = ROLE_WEIGHTS[role];
    let score = 0;
    let totalWeight = 0;

    for (const [statKey, weight] of Object.entries(weights)) {
      const rawValue = (stats as Record<string, number>)[statKey] ?? 0;
      const baseline = STAT_BASELINES[statKey as keyof BaseStats];
      // Soft-cap formula: each stat contributes relative to its baseline
      const normalized = Math.min(2.0, rawValue / baseline) * 50; // 0-100 range
      score += normalized * (weight ?? 0);
      totalWeight += weight ?? 0;
    }

    return Math.min(100, Math.round((score / totalWeight) * 100) / 100);
  }

  /**
   * Combat score — combines DPS potential with survivability.
   * DPS = ATK × (1 + CritRate/100 × (CritDmg/100 - 1)) × (VoidPwr/50)
   * EHP = HP × (1 + DEF/250) × (1 + VoidRes/100)
   */
  static combatScore(stats: BaseStats): number {
    const dps = stats.atk
      * (1 + (stats.critRate / 100) * (stats.critDmg / 100 - 1))
      * (1 + stats.voidPwr / 100);

    const ehp = stats.hp * (1 + stats.def / 250) * (1 + stats.voidRes / 100);

    // Normalize and blend: 60% offense, 40% defense
    const dpsNorm = Math.min(100, (dps / 5000) * 100);
    const ehpNorm = Math.min(100, (ehp / 30000) * 100);

    return Math.round(dpsNorm * 0.6 + ehpNorm * 0.4);
  }

  static zeroStats(): BaseStats {
    return { atk: 0, def: 0, hp: 0, spd: 0, critRate: 0, critDmg: 0, voidRes: 0, voidPwr: 0, energy: 0, accuracy: 0 };
  }

  private static statTypeToKey(stat: string | undefined): keyof BaseStats | null {
    const map: Record<string, keyof BaseStats> = {
      ATK: 'atk', DEF: 'def', HP: 'hp', SPD: 'spd',
      CRIT_RATE: 'critRate', CRIT_DMG: 'critDmg',
      VOID_RES: 'voidRes', VOID_PWR: 'voidPwr',
      ENERGY: 'energy', ACCURACY: 'accuracy',
    };
    return stat ? (map[stat] ?? null) : null;
  }
}

// ─── Build Optimizer ─────────────────────────────────────────

export class BuildOptimizer {
  /**
   * Main entry point — routes to the appropriate algorithm.
   */
  static optimize(
    pet: Pet,
    allEquipment: Equipment[],
    request: BuildRequest,
    strategy: OptimizationStrategy,
  ): OptimizationResult {
    const start = Date.now();

    // Partition equipment by slot
    const bySlot = this.partitionBySlot(allEquipment, request.constraints);

    let result: OptimizationResult;

    switch (strategy.method) {
      case 'GENETIC':
        result = this.geneticAlgorithm(pet, bySlot, request, {
          populationSize: strategy.populationSize ?? 100,
          generations: strategy.maxIterations ?? 50,
          mutationRate: strategy.mutationRate ?? 0.1,
          crossoverRate: 0.7,
          elitismRate: 0.1,
          fitnessFunction: request.role,
        });
        break;
      case 'MONTE_CARLO':
        result = this.monteCarlo(pet, bySlot, request, {
          iterations: strategy.maxIterations ?? 10000,
          confidenceLevel: 0.95,
        });
        break;
      default:
        result = this.bruteForce(pet, bySlot, request, strategy.maxIterations ?? 50000);
    }

    result.computationMs = Date.now() - start;
    return result;
  }

  // ─── Brute Force (exhaustive for small sets) ───────────────

  private static bruteForce(
    pet: Pet,
    bySlot: Record<EquipmentSlot, Equipment[]>,
    request: BuildRequest,
    maxBuilds: number,
  ): OptimizationResult {
    const weapons = bySlot[EquipmentSlot.WEAPON];
    const armors = bySlot[EquipmentSlot.ARMOR];
    const accessories = bySlot[EquipmentSlot.ACCESSORY];
    const relics = bySlot[EquipmentSlot.RELIC];
    const cores = bySlot[EquipmentSlot.CORE];

    let best: { score: number; combo: BuildEquipment } | null = null;
    const topBuilds: Array<{ score: number; combo: BuildEquipment }> = [];
    let iterations = 0;

    outer:
    for (const weapon of weapons) {
      for (const armor of armors) {
        for (const accessory of accessories) {
          for (const relic of relics) {
            for (const core of cores) {
              if (iterations >= maxBuilds) break outer;
              iterations++;

              const combo: BuildEquipment = { weapon, armor, accessory, relic, core };
              const calc = StatEngine.calculate({
                pet, level: request.petLevel,
                equipment: combo, activePassives: pet.passives,
              });
              const score = StatEngine.scoreForRole(calc.finalStats, request.role);

              if (!best || score > best.score) {
                best = { score, combo };
              }
              if (topBuilds.length < 10 || score > topBuilds[topBuilds.length - 1].score) {
                topBuilds.push({ score, combo });
                topBuilds.sort((a, b) => b.score - a.score);
                if (topBuilds.length > 10) topBuilds.pop();
              }
            }
          }
        }
      }
    }

    return this.buildResult(pet, best, topBuilds, iterations, false, 'BRUTE_FORCE', request);
  }

  // ─── Genetic Algorithm ────────────────────────────────────

  private static geneticAlgorithm(
    pet: Pet,
    bySlot: Record<EquipmentSlot, Equipment[]>,
    request: BuildRequest,
    config: GeneticAlgorithmConfig,
  ): OptimizationResult {
    type Chromosome = BuildEquipment;
    type Individual = { genes: Chromosome; fitness: number };

    const { populationSize, generations, mutationRate, crossoverRate, elitismRate } = config;
    const scoreHistory: number[] = [];

    // Initialize random population
    let population: Individual[] = Array.from({ length: populationSize }, () => {
      const genes = this.randomBuild(bySlot);
      return { genes, fitness: this.fitness(pet, genes, request) };
    });

    const eliteCount = Math.floor(populationSize * elitismRate);
    let converged = false;
    let prevBest = 0;
    let stagnantGens = 0;

    for (let gen = 0; gen < generations; gen++) {
      // Sort by fitness descending
      population.sort((a, b) => b.fitness - a.fitness);
      scoreHistory.push(population[0].fitness);

      // Convergence check
      if (Math.abs(population[0].fitness - prevBest) < 0.01) {
        stagnantGens++;
        if (stagnantGens >= 8) { converged = true; break; }
      } else {
        stagnantGens = 0;
      }
      prevBest = population[0].fitness;

      const elite = population.slice(0, eliteCount);
      const newPop: Individual[] = [...elite];

      while (newPop.length < populationSize) {
        // Tournament selection
        const parent1 = this.tournamentSelect(population, 5);
        const parent2 = this.tournamentSelect(population, 5);

        let child = Math.random() < crossoverRate
          ? this.crossover(parent1.genes, parent2.genes)
          : parent1.genes;

        if (Math.random() < mutationRate) {
          child = this.mutate(child, bySlot);
        }

        newPop.push({ genes: child, fitness: this.fitness(pet, child, request) });
      }

      population = newPop;
    }

    population.sort((a, b) => b.fitness - a.fitness);

    return this.buildResult(
      pet,
      { score: population[0].fitness, combo: population[0].genes },
      population.slice(0, 10).map(p => ({ score: p.fitness, combo: p.genes })),
      populationSize * generations,
      converged,
      'GENETIC',
      request,
      scoreHistory,
    );
  }

  // ─── Monte Carlo Simulation ───────────────────────────────

  private static monteCarlo(
    pet: Pet,
    bySlot: Record<EquipmentSlot, Equipment[]>,
    request: BuildRequest,
    config: MonteCarloConfig,
  ): OptimizationResult {
    const { iterations } = config;
    let best: { score: number; combo: BuildEquipment } | null = null;
    const topBuilds: Array<{ score: number; combo: BuildEquipment }> = [];
    const scoreHistory: number[] = [];

    for (let i = 0; i < iterations; i++) {
      const combo = this.randomBuild(bySlot);
      const score = this.fitness(pet, combo, request);

      if (!best || score > best.score) {
        best = { score, combo };
        scoreHistory.push(score);
      }

      if (topBuilds.length < 10 || score > topBuilds[topBuilds.length - 1].score) {
        topBuilds.push({ score, combo });
        topBuilds.sort((a, b) => b.score - a.score);
        if (topBuilds.length > 10) topBuilds.pop();
      }
    }

    return this.buildResult(pet, best, topBuilds, iterations, false, 'MONTE_CARLO', request, scoreHistory);
  }

  // ─── Helper Methods ───────────────────────────────────────

  private static fitness(pet: Pet, combo: BuildEquipment, request: BuildRequest): number {
    const calc = StatEngine.calculate({
      pet, level: request.petLevel,
      equipment: combo, activePassives: pet.passives,
    });
    return StatEngine.scoreForRole(calc.finalStats, request.role);
  }

  private static randomBuild(bySlot: Record<EquipmentSlot, Equipment[]>): BuildEquipment {
    const pick = (arr: Equipment[]) => arr[Math.floor(Math.random() * arr.length)];
    return {
      weapon: pick(bySlot[EquipmentSlot.WEAPON]),
      armor: pick(bySlot[EquipmentSlot.ARMOR]),
      accessory: pick(bySlot[EquipmentSlot.ACCESSORY]),
      relic: pick(bySlot[EquipmentSlot.RELIC]),
      core: pick(bySlot[EquipmentSlot.CORE]),
    };
  }

  private static crossover(p1: BuildEquipment, p2: BuildEquipment): BuildEquipment {
    // Uniform crossover — each slot independently picked from p1 or p2
    return {
      weapon: Math.random() < 0.5 ? p1.weapon : p2.weapon,
      armor: Math.random() < 0.5 ? p1.armor : p2.armor,
      accessory: Math.random() < 0.5 ? p1.accessory : p2.accessory,
      relic: Math.random() < 0.5 ? p1.relic : p2.relic,
      core: Math.random() < 0.5 ? p1.core : p2.core,
    };
  }

  private static mutate(genes: BuildEquipment, bySlot: Record<EquipmentSlot, Equipment[]>): BuildEquipment {
    const slots = Object.keys(bySlot) as EquipmentSlot[];
    const slotToMutate = slots[Math.floor(Math.random() * slots.length)];
    const slotKey = slotToMutate.toLowerCase() as keyof BuildEquipment;
    const options = bySlot[slotToMutate];
    const newItem = options[Math.floor(Math.random() * options.length)];
    return { ...genes, [slotKey]: newItem };
  }

  private static tournamentSelect(
    population: Array<{ genes: BuildEquipment; fitness: number }>,
    k: number,
  ) {
    let best = population[Math.floor(Math.random() * population.length)];
    for (let i = 1; i < k; i++) {
      const challenger = population[Math.floor(Math.random() * population.length)];
      if (challenger.fitness > best.fitness) best = challenger;
    }
    return best;
  }

  private static partitionBySlot(
    equipment: Equipment[],
    constraints?: BuildRequest['constraints'],
  ): Record<EquipmentSlot, Equipment[]> {
    const result: Record<EquipmentSlot, Equipment[]> = {
      [EquipmentSlot.WEAPON]: [],
      [EquipmentSlot.ARMOR]: [],
      [EquipmentSlot.ACCESSORY]: [],
      [EquipmentSlot.RELIC]: [],
      [EquipmentSlot.CORE]: [],
    };

    for (const eq of equipment) {
      if (constraints?.excludeEquipment?.includes(eq.id)) continue;
      if (constraints?.maxTier && eq.tier > constraints.maxTier) continue;
      result[eq.slot].push(eq);
    }

    // Ensure at least one item per slot (fallback)
    for (const slot of Object.values(EquipmentSlot)) {
      if (result[slot].length === 0) {
        const fallback = equipment.find(e => e.slot === slot);
        if (fallback) result[slot].push(fallback);
      }
    }

    return result;
  }

  private static buildResult(
    pet: Pet,
    best: { score: number; combo: BuildEquipment } | null,
    topBuilds: Array<{ score: number; combo: BuildEquipment }>,
    iterations: number,
    converged: boolean,
    algorithm: string,
    request: BuildRequest,
    scoreHistory?: number[],
  ): OptimizationResult {
    if (!best) {
      return {
        bestBuild: this.emptyBuild(pet, request),
        topBuilds: [],
        iterationsRan: 0,
        convergenceReached: false,
        computationMs: 0,
        algorithm,
        scoreHistory,
      };
    }

    const calc = StatEngine.calculate({
      pet, level: request.petLevel,
      equipment: best.combo, activePassives: pet.passives,
    });

    const buildRecord: Build = {
      id: `opt_${Date.now()}`,
      petId: pet.id,
      petLevel: request.petLevel,
      role: request.role,
      gameMode: request.gameMode,
      equipment: best.combo,
      finalStats: calc.finalStats,
      combatScore: StatEngine.combatScore(calc.finalStats),
      dpsScore: StatEngine.scoreForRole(calc.finalStats, BuildRole.DPS),
      tankScore: StatEngine.scoreForRole(calc.finalStats, BuildRole.TANK),
      supportScore: StatEngine.scoreForRole(calc.finalStats, BuildRole.SUPPORT),
      overallScore: best.score,
      mathScore: best.score,
      communityScore: 0, // Set by meta service later
      confidenceScore: 0,
      patchVersion: '1.3.0',
      isOutdated: false,
      tags: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    return {
      bestBuild: buildRecord,
      topBuilds: topBuilds.slice(0, 10).map(t => ({
        ...buildRecord,
        id: `opt_${Date.now()}_${Math.random()}`,
        equipment: t.combo,
        overallScore: t.score,
        mathScore: t.score,
        finalStats: StatEngine.calculate({ pet, level: request.petLevel, equipment: t.combo, activePassives: pet.passives }).finalStats,
      })),
      iterationsRan: iterations,
      convergenceReached: converged,
      computationMs: 0,
      algorithm,
      scoreHistory,
    };
  }

  private static emptyBuild(pet: Pet, request: BuildRequest): Build {
    return {
      id: 'empty', petId: pet.id, petLevel: request.petLevel,
      role: request.role, gameMode: request.gameMode,
      equipment: {}, finalStats: StatEngine.zeroStats(),
      combatScore: 0, dpsScore: 0, tankScore: 0, supportScore: 0,
      overallScore: 0, mathScore: 0, communityScore: 0, confidenceScore: 0,
      patchVersion: '1.3.0', isOutdated: false, tags: [],
      createdAt: new Date(), updatedAt: new Date(),
    };
  }
}

// Re-export EquipmentSlot for convenience (used internally)
import { EquipmentSlot } from '../shared/types';
