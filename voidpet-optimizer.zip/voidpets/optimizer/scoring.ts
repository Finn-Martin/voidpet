// ============================================================
// VOIDPETS META BUILD OPTIMIZER — Confidence Scoring System
// Blends mathematical optimization with community meta signals
// to produce a multi-dimensional confidence score (0-100).
// ============================================================

import { Build, MetaScore, CommunityBuildMention, PatchVersion, ConfidenceBreakdown } from '../shared/types';

// ─── Confidence Score Weights ─────────────────────────────────
// Total must = 100
const WEIGHTS = {
  officialData: 25,   // From official game data + math optimization
  redditConsensus: 25, // Community Reddit agreement
  patchFreshness: 25,  // How recent the patch is
  popularity: 25,      // How often the build is used
};

const CURRENT_PATCH = '1.3.0';

// ─── Confidence Calculator ────────────────────────────────────

export class ConfidenceScorer {
  /**
   * Generate a full confidence breakdown for a build.
   *
   * Score 1: Official Data Score (0-25)
   *   - Based on mathematical optimization score from our engine
   *   - Official patch notes alignment
   *
   * Score 2: Reddit Consensus Score (0-25)
   *   - How many Reddit posts mention this build positively
   *   - Upvote ratios and sentiment analysis
   *
   * Score 3: Patch Freshness Score (0-25)
   *   - Decays over time relative to patch release date
   *   - Major reworks reduce scores for old builds
   *
   * Score 4: Popularity Score (0-25)
   *   - Community build mention frequency
   *   - Usage in top-tier content
   */
  static score(
    build: Build,
    metaScore: MetaScore | null,
    communityMentions: CommunityBuildMention[],
    patches: PatchVersion[],
    redditPosts: { sentiment: number; score: number }[],
  ): ConfidenceBreakdown {
    const official = this.officialDataScore(build, metaScore);
    const reddit = this.redditConsensusScore(redditPosts, metaScore);
    const freshness = this.patchFreshnessScore(build, patches);
    const popularity = this.popularityScore(communityMentions);

    const total = official + reddit + freshness + popularity;

    return {
      officialDataScore: official,
      redditConsensus: reddit,
      patchFreshness: freshness,
      popularityScore: popularity,
      total: Math.min(100, Math.round(total)),
    };
  }

  /** 0-25: Based on our math engine's score, normalized to quarter */
  private static officialDataScore(build: Build, metaScore: MetaScore | null): number {
    const mathNorm = (build.mathScore / 100) * WEIGHTS.officialData;

    // Bonus if meta score confirms our math
    const metaBonus = metaScore
      ? (metaScore.mathScore / 100) * 3 // up to +3 bonus
      : 0;

    return Math.min(WEIGHTS.officialData, mathNorm + metaBonus);
  }

  /** 0-25: Reddit sentiment and consensus signals */
  private static redditConsensusScore(
    posts: { sentiment: number; score: number }[],
    metaScore: MetaScore | null,
  ): number {
    if (posts.length === 0 && !metaScore) return WEIGHTS.redditConsensus * 0.3; // baseline

    let totalSentiment = 0;
    let totalWeight = 0;

    for (const post of posts) {
      const weight = Math.log(post.score + 1); // log-weight by upvotes
      totalSentiment += post.sentiment * weight;
      totalWeight += weight;
    }

    const avgSentiment = totalWeight > 0
      ? totalSentiment / totalWeight
      : (metaScore?.redditSentiment ?? 0);

    // Map sentiment (-1 to 1) → score (0 to WEIGHTS.redditConsensus)
    const sentimentScore = ((avgSentiment + 1) / 2) * WEIGHTS.redditConsensus;

    // Bonus for quantity of mentions
    const mentionBonus = Math.min(3, posts.length / 10);
    const apiScore = metaScore ? (metaScore.communityScore / 100) * WEIGHTS.redditConsensus : 0;

    return Math.min(WEIGHTS.redditConsensus, sentimentScore * 0.5 + apiScore * 0.5 + mentionBonus);
  }

  /**
   * 0-25: How fresh is this build relative to the current patch?
   * - Current patch build = full score
   * - 1 patch old = 75% score
   * - 2+ patches old = 50% score
   * - Build explicitly marked outdated = 25% score
   */
  private static patchFreshnessScore(build: Build, patches: PatchVersion[]): number {
    if (build.isOutdated) return WEIGHTS.patchFreshness * 0.25;

    const sorted = [...patches].sort((a, b) =>
      new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime()
    );

    const currentIndex = sorted.findIndex(p => p.version === CURRENT_PATCH);
    const buildIndex = sorted.findIndex(p => p.version === build.patchVersion);

    if (buildIndex === -1 || buildIndex === currentIndex) {
      return WEIGHTS.patchFreshness; // Current patch = full
    }

    const patchesOld = buildIndex - currentIndex;

    if (patchesOld === 1) return WEIGHTS.patchFreshness * 0.75;
    if (patchesOld === 2) return WEIGHTS.patchFreshness * 0.50;
    return WEIGHTS.patchFreshness * 0.25;
  }

  /** 0-25: How popular is this build in the community? */
  private static popularityScore(mentions: CommunityBuildMention[]): number {
    if (mentions.length === 0) return WEIGHTS.popularity * 0.2; // baseline

    // Total frequency across all mentions
    const totalFreq = mentions.reduce((sum, m) => sum + m.frequency, 0);
    const maxExpectedFreq = 200; // threshold for max score

    const freqScore = Math.min(1, totalFreq / maxExpectedFreq) * WEIGHTS.popularity;

    // Recency bonus — favor more recent mentions
    const now = Date.now();
    const recentMentions = mentions.filter(m =>
      now - new Date(m.lastSeen).getTime() < 7 * 24 * 60 * 60 * 1000 // 7 days
    );
    const recencyBonus = recentMentions.length > 0 ? 2 : 0;

    return Math.min(WEIGHTS.popularity, freqScore + recencyBonus);
  }

  /** Generate a human-readable recommendation string */
  static getRecommendation(breakdown: ConfidenceBreakdown): string {
    const { total } = breakdown;

    if (total >= 88) return '🏆 Meta-defining build. Highly recommended for competitive play.';
    if (total >= 75) return '✅ Strong meta build with solid community backing.';
    if (total >= 62) return '⚡ Viable build. Good for most content but not peak meta.';
    if (total >= 50) return '⚠️ Situational build. May work in specific scenarios.';
    if (total >= 35) return '🔻 Below-average confidence. Consider alternatives.';
    return '❌ Low confidence. Either outdated or lacks community validation.';
  }

  /** Generate warnings for low sub-scores */
  static getWarnings(breakdown: ConfidenceBreakdown, build: Build): string[] {
    const warnings: string[] = [];

    if (build.isOutdated || build.patchVersion !== CURRENT_PATCH) {
      warnings.push('⚠️ This build is from a previous patch and may no longer be optimal.');
    }
    if (breakdown.patchFreshness < 10) {
      warnings.push('📅 Build data is significantly outdated.');
    }
    if (breakdown.redditConsensus < 8) {
      warnings.push('👥 Limited community data for this build configuration.');
    }
    if (breakdown.officialDataScore < 12) {
      warnings.push('📊 Mathematical optimization score is below average for this role.');
    }
    if (breakdown.popularityScore < 5) {
      warnings.push('🔍 Very few community players are using this build.');
    }

    return warnings;
  }

  /** Tier grade from score */
  static getTierLabel(score: number): string {
    if (score >= 92) return 'S+';
    if (score >= 82) return 'S';
    if (score >= 72) return 'A';
    if (score >= 62) return 'B';
    if (score >= 50) return 'C';
    if (score >= 38) return 'D';
    return 'F';
  }
}
