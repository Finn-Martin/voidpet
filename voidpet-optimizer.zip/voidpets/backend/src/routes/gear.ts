import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { cacheGet, cacheSet } from '../services/cache';
const router = Router();
const prisma = new PrismaClient();

router.get('/', async (req, res) => {
  try {
    const { slot, rarity, source, minFloor } = req.query as Record<string,string>;
    const cached = await cacheGet('gear:all');
    let gear = cached ? JSON.parse(cached) : null;
    if (!gear) {
      gear = await prisma.gearItem.findMany({ orderBy: [{ rarity:'desc' },{ name:'asc' }] });
      await cacheSet('gear:all', JSON.stringify(gear), 600);
    }
    if (slot) gear = gear.filter((g: any) => g.slot === slot.toUpperCase());
    if (rarity) gear = gear.filter((g: any) => g.rarity === rarity.toUpperCase());
    if (source) gear = gear.filter((g: any) => g.source.toLowerCase() === source.toLowerCase());
    if (minFloor) gear = gear.filter((g: any) => !g.floorRequired || g.floorRequired <= parseInt(minFloor));
    const bySlot = gear.reduce((acc: any, g: any) => { acc[g.slot] = (acc[g.slot]??0)+1; return acc; }, {});
    res.json({ success: true, data: { gear, total: gear.length, bySlot }, meta: { patchVersion:'5.25.8' } });
  } catch (e: any) { res.status(500).json({ success: false, error: e.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const gear = await prisma.gearItem.findUnique({ where: { id: req.params.id } });
    if (!gear) return res.status(404).json({ success: false, error: 'Gear not found' });
    res.json({ success: true, data: gear });
  } catch (e: any) { res.status(500).json({ success: false, error: e.message }); }
});

export default router;
