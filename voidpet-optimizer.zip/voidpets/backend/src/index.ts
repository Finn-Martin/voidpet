import express from 'express';
import cors from 'cors';
import compression from 'compression';
import petsRouter from './routes/pets';
import gearRouter from './routes/gear';
import buildsRouter from './routes/builds';
import metaRouter from './routes/meta';
import patchesRouter from './routes/patches';
import { rateLimiter } from './middleware/rateLimit';
import { requestLogger } from './middleware/logger';
import { errorHandler } from './middleware/errorHandler';

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL ?? '*', credentials: true }));
app.use(compression());
app.use(express.json({ limit: '1mb' }));
app.use(requestLogger);
app.use('/api/', rateLimiter({ windowMs: 900000, max: 200 }));

app.use('/api/pets', petsRouter);
app.use('/api/gear', gearRouter);
app.use('/api/builds', buildsRouter);
app.use('/api/meta', metaRouter);
app.use('/api/patches', patchesRouter);

app.get('/health', (_, res) => res.json({ status:'ok', version:'1.0.0' }));
app.use(errorHandler);

const PORT = parseInt(process.env.PORT ?? '4000', 10);
app.listen(PORT, () => console.log(`🚀 Voidpet Dungeon API on port ${PORT}`));
export default app;
