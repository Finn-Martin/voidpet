import { PrismaClient, GearSlot, PetRole } from '@prisma/client';
const prisma = new PrismaClient();

export interface OptReq { petId: string; evolutionLevel: number; priorityStat: string; excludeGear?: string[]; minFloor?: number; algorithm?: string; }

const ROLE_W: Record<string, Record<string, number>> = {
  FIGHTER: { bonusAtk:0.40, bonusDef:0.10, bonusStamina:0.15, bonusSpd:0.20, bonusCrit:0.15 },
  TANK:    { bonusAtk:0.10, bonusDef:0.35, bonusStamina:0.35, bonusSpd:0.10, bonusCrit:0.10 },
  HEALER:  { bonusAtk:0.15, bonusDef:0.20, bonusStamina:0.25, bonusSpd:0.30, bonusCrit:0.10 },
};
const BASELINES: Record<string, number> = { bonusAtk:80, bonusDef:80, bonusStamina:100, bonusSpd:80, bonusCrit:60 };

function score(gear: Record<string,number>, role: string, override?: string): number {
  const w = ROLE_W[role] ?? ROLE_W.FIGHTER;
  const eff = override ? { ...w, [override]: (w[override]??0) * 1.5 } : w;
  return Object.entries(eff).reduce((s,[k,wt]) => s + Math.min(2, (gear[k]??0)/BASELINES[k]) * 50 * wt, 0);
}

function computeStats(pet: any, evo: number, gear: any[]) {
  const lvl = evo;
  return {
    atk:     Math.round((pet.baseAtk + pet.growthAtk * lvl) + gear.reduce((s,g)=>s+(g?.bonusAtk??0),0)),
    def:     Math.round((pet.baseDef + pet.growthDef * lvl) + gear.reduce((s,g)=>s+(g?.bonusDef??0),0)),
    stamina: Math.round((pet.baseStamina + pet.growthStamina * lvl) + gear.reduce((s,g)=>s+(g?.bonusStamina??0),0)),
    spd:     Math.round((pet.baseSpd + pet.growthSpd * lvl) + gear.reduce((s,g)=>s+(g?.bonusSpd??0),0)),
    crit:    Math.round(Math.min(100, (pet.baseCrit + pet.growthCrit * lvl) + gear.reduce((s,g)=>s+(g?.bonusCrit??0),0)) * 10) / 10,
  };
}

export async function optimizeBuild(req: OptReq) {
  const start = Date.now();
  const pet = await prisma.voidPet.findUnique({ where: { id: req.petId } });
  if (!pet) throw new Error('Pet not found');

  const allGear = await prisma.gearItem.findMany({
    where: {
      ...(req.excludeGear?.length ? { id: { notIn: req.excludeGear } } : {}),
      ...(req.minFloor ? { OR: [{ floorRequired: null }, { floorRequired: { lte: req.minFloor } }] } : {}),
    }
  });

  const bySlot: Record<string, typeof allGear> = { HEAD:[], NECK:[], TRINKET1:[], TRINKET2:[] };
  for (const g of allGear) bySlot[g.slot as string]?.push(g);
  for (const s of Object.keys(bySlot)) if (!bySlot[s].length) bySlot[s] = [null as any];

  const role = pet.role as string;
  const pri = req.priorityStat ? `bonus${req.priorityStat.charAt(0)+req.priorityStat.slice(1).toLowerCase()}` : undefined;

  let bestScore = -1, bestCombo: any = null;
  const top5: any[] = [];
  let iters = 0;

  if (req.algorithm === 'GREEDY' || bySlot.HEAD.length * bySlot.NECK.length * bySlot.TRINKET1.length * bySlot.TRINKET2.length > 20000) {
    // Greedy: pick best per slot independently
    const picked: Record<string, any> = {};
    for (const slot of ['HEAD','NECK','TRINKET1','TRINKET2']) {
      let bs = -1, bg: any = null;
      for (const g of bySlot[slot]) {
        const s = score({ bonusAtk:g?.bonusAtk??0, bonusDef:g?.bonusDef??0, bonusStamina:g?.bonusStamina??0, bonusSpd:g?.bonusSpd??0, bonusCrit:g?.bonusCrit??0 }, role, pri);
        if (s > bs) { bs = s; bg = g; }
      }
      picked[slot] = bg;
    }
    bestCombo = picked;
    bestScore = score({ bonusAtk:(picked.HEAD?.bonusAtk??0)+(picked.NECK?.bonusAtk??0)+(picked.TRINKET1?.bonusAtk??0)+(picked.TRINKET2?.bonusAtk??0), bonusDef:(picked.HEAD?.bonusDef??0)+(picked.NECK?.bonusDef??0)+(picked.TRINKET1?.bonusDef??0)+(picked.TRINKET2?.bonusDef??0), bonusStamina:(picked.HEAD?.bonusStamina??0)+(picked.NECK?.bonusStamina??0)+(picked.TRINKET1?.bonusStamina??0)+(picked.TRINKET2?.bonusStamina??0), bonusSpd:(picked.HEAD?.bonusSpd??0)+(picked.NECK?.bonusSpd??0)+(picked.TRINKET1?.bonusSpd??0)+(picked.TRINKET2?.bonusSpd??0), bonusCrit:(picked.HEAD?.bonusCrit??0)+(picked.NECK?.bonusCrit??0)+(picked.TRINKET1?.bonusCrit??0)+(picked.TRINKET2?.bonusCrit??0) }, role, pri);
    iters = bySlot.HEAD.length + bySlot.NECK.length + bySlot.TRINKET1.length + bySlot.TRINKET2.length;
  } else {
    // Brute force for small sets
    for (const h of bySlot.HEAD) for (const n of bySlot.NECK) for (const t1 of bySlot.TRINKET1) for (const t2 of bySlot.TRINKET2) {
      iters++;
      const combo = { bonusAtk:(h?.bonusAtk??0)+(n?.bonusAtk??0)+(t1?.bonusAtk??0)+(t2?.bonusAtk??0), bonusDef:(h?.bonusDef??0)+(n?.bonusDef??0)+(t1?.bonusDef??0)+(t2?.bonusDef??0), bonusStamina:(h?.bonusStamina??0)+(n?.bonusStamina??0)+(t1?.bonusStamina??0)+(t2?.bonusStamina??0), bonusSpd:(h?.bonusSpd??0)+(n?.bonusSpd??0)+(t1?.bonusSpd??0)+(t2?.bonusSpd??0), bonusCrit:(h?.bonusCrit??0)+(n?.bonusCrit??0)+(t1?.bonusCrit??0)+(t2?.bonusCrit??0) };
      const sc = score(combo, role, pri);
      if (sc > bestScore) { bestScore = sc; bestCombo = { HEAD:h, NECK:n, TRINKET1:t1, TRINKET2:t2 }; }
      if (top5.length < 5 || sc > top5[top5.length-1].score) {
        top5.push({ score:sc, combo:{ HEAD:h, NECK:n, TRINKET1:t1, TRINKET2:t2 } });
        top5.sort((a,b)=>b.score-a.score); if (top5.length > 5) top5.pop();
      }
    }
  }

  const gear = [bestCombo?.HEAD, bestCombo?.NECK, bestCombo?.TRINKET1, bestCombo?.TRINKET2];
  const stats = computeStats(pet, req.evolutionLevel, gear);

  return {
    pet, loadout: bestCombo, computedStats: stats,
    score: Math.min(100, Math.round(bestScore * 100) / 100),
    alternatives: top5.slice(1).map(t => ({ loadout: t.combo, score: Math.min(100, Math.round(t.score*100)/100), stats: computeStats(pet, req.evolutionLevel, [t.combo.HEAD,t.combo.NECK,t.combo.TRINKET1,t.combo.TRINKET2]) })),
    computedMs: Date.now() - start, algorithm: req.algorithm ?? 'BRUTE_FORCE', iterationCount: iters,
  };
}
